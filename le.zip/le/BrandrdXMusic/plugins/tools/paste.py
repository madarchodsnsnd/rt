import asyncio
import os
import re

import aiofiles
from pykeyboard import InlineKeyboard
from pyrogram import filters
from pyrogram.types import InlineKeyboardButton

from aiohttp import ClientSession
from BrandrdXMusic import app
from BrandrdXMusic.utils.errors import capture_err
from BrandrdXMusic.utils.pastebin import HottyBin

# Regex to check allowed file types (text/json/yaml/xml etc.)
pattern = re.compile(r"^text/|json$|yaml$|xml$|toml$|x-sh$|x-shellscript$")

async def isPreviewUp(preview: str) -> bool:
    """Check if the pastebin preview URL is accessible."""
    async with ClientSession() as session:
        for _ in range(7):  # Retry up to 7 times
            try:
                async with session.head(preview, timeout=2) as resp:
                    status = resp.status
                    size = resp.content_length
            except asyncio.exceptions.TimeoutError:
                return False
            if status == 404 or (status == 200 and size == 0):
                await asyncio.sleep(0.4)  # Wait and retry
            else:
                return True if status == 200 else False
        return False

@app.on_message(filters.command("paste"))
@capture_err  # Error handler decorator
async def paste_func(_, message):
    # Check if the command is a reply
    if not message.reply_to_message:
        return await message.reply_text("Reply to a message with /paste")

    m = await message.reply_text("Pasting...")

    # Handle text messages
    if message.reply_to_message.text:
        content = str(message.reply_to_message.text)

    # Handle document (file) messages
    elif message.reply_to_message.document:
        document = message.reply_to_message.document

        # File size check (max 1MB)
        if document.file_size > 1048576:
            return await m.edit("You can only paste files smaller than 1MB.")

        # File type check (only text-based files allowed)
        if not pattern.search(document.mime_type):
            return await m.edit("Only text files can be pasted.")

        # Download and read the file
        doc = await message.reply_to_message.download()
        async with aiofiles.open(doc, mode="r") as f:
            content = await f.read()
        os.remove(doc)  # Clean up the downloaded file

    # Upload content to HottyBin (pastebin service)
    link = await HottyBin(content)
    preview = link 

    # Create an inline button for the paste link
    button = InlineKeyboard(row_width=1)
    button.add(InlineKeyboardButton(text="• ᴘᴀsᴛᴇ ʟɪɴᴋ •", url=link))

    # Send the link to the user
    await m.delete()
    try:
        await message.reply(
            "ʜᴇʀᴇ ɪs ʏᴏᴜʀ ᴘᴀsᴛᴇ ʟɪɴᴋ :",
            quote=False,
            reply_markup=button
        )
    except Exception:
        pass  # Fail silently if sending fails